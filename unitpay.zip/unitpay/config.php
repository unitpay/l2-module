<?php return array(
'ITEM_PRICE' => '30',
'ITEM_ID' => '4037',
'SECRET_KEY' => 'sdfsdf',
'DB_HOST' => 'localhost',
'DB_USER' => 'homestead',
'DB_PASS' => 'secret',
'DB_NAME' => 'l2',
'ITEM_TABLE' => 'items_delayed',
'PROJECT_ID' => '1',
); ?>