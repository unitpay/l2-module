<?php

include_once 'lib/ConfigWritter.php';
include_once 'lib/Model.php';
include_once 'lib/Logger.php';

$debug = ConfigWritter::getInstance()->getParameter('DEBUG');
if ($debug){
    Logger::getInstance()->writeString('test string', 'TEST TITLE STRING');
}